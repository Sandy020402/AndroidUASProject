package kominfo.go.id.storage.halamanlogin;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    //private DatabaseHelperUser dbHelper;
    private EditText TxNoInduk;
    private EditText TxNama;
    private Spinner TxProdi;
    private EditText TxEmail;
    private EditText TxPassword;
    Button BtnRegister;
    DatabaseHelperUser dbHelper;




    public static final String FILENAME = "register";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DatabaseHelperUser(this);

        TxNoInduk = (EditText) findViewById(R.id.et_register_nomorinduk);
        TxNama = (EditText) findViewById(R.id.et_login_nomorinduk);
        TxPassword = (EditText) findViewById(R.id.et_register_password);
        TxProdi = (Spinner) findViewById(R.id.spinner_program_studi);
        TxEmail = (EditText) findViewById(R.id.et_login_password);
        BtnRegister = (Button) findViewById(R.id.btDoneRegister);

        BtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String no_induk = TxNoInduk.getText().toString().trim();
                String nama = TxNama.getText().toString().trim();
                String email = TxEmail.getText().toString().trim();
                String prodi = TxProdi.getSelectedItem().toString().trim();
                String password = TxPassword.getText().toString().trim();
                String Class = "user";


                ContentValues values = new ContentValues();

                values.put(DatabaseHelperUser.COL_1, no_induk);
                values.put(DatabaseHelperUser.COL_2, nama);
                values.put(DatabaseHelperUser.COL_3, email);
                values.put(DatabaseHelperUser.COL_4, prodi);
                values.put(DatabaseHelperUser.COL_5, password);
                values.put(DatabaseHelperUser.COL_6, Class);
                dbHelper.addUser(values);
                Toast.makeText(RegisterActivity.this, "Register Sukses", Toast.LENGTH_SHORT).show();
                finish();
            }
        });






    }


}