package kominfo.go.id.storage.halamanlogin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;

public class DatabaseHelperUser extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Inventory.db";
    public static final int DATABASE_VERSION = 2;
    public static final String TABLE_NAME = "Barang";
    public static final String COL_1 = "kode_barang";
    public static final String COL_2 = "nama_barang";
    public static final String COL_3 = "kuantitas";

    public static String u;
    private SQLiteDatabase db;


    public DatabaseHelperUser(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_1 + " VARCHAR PRIMARY KEY, " +
                COL_2 + " VARCHAR, " + COL_3 + " INTEGER) ";

        db.execSQL(query);

    }

    public ArrayList<HashMap<String, String>> getAllData() {
        ArrayList<HashMap<String, String>> wordList;
        wordList = new ArrayList<HashMap<String, String>>();
        String selectQuery = "SELECT * FROM User WHERE no_induk = "+"'"+u+"'";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        if (cursor.moveToFirst())
        {
            do {
                HashMap<String, String> map = new HashMap<String, String>();
                map.put(COL_1, cursor.getString(0));
                map.put(COL_2, cursor.getString(1));
                map.put(COL_3, cursor.getString(2));

                wordList.add(map);
            } while (cursor.moveToNext());

        }
        Log.e("select sqlite", "" + wordList);
        database.close();
        return wordList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addBarang(ContentValues values) {
        db = this.getWritableDatabase();
        db.insert(TABLE_NAME, null, values);
    }

    public void refresh()
    {
        db = this.getWritableDatabase();
    }

}