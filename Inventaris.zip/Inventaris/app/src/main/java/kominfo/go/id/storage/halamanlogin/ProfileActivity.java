package kominfo.go.id.storage.halamanlogin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;

public class ProfileActivity extends AppCompatActivity {
    private TextView TxNoInduk;
    private TextView TxNama;
    private TextView TxProdi;
    private TextView TxEmail,TxClass;
    public String k;
    Button BtnLogout;
    DatabaseHelperUser dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.halaman_profile);

        dbHelper = new DatabaseHelperUser(this);
        dbHelper.getAllData();
        TxNoInduk = (TextView) findViewById(R.id.tv_profile_nomorinduk);
        TxNama = (TextView) findViewById(R.id.tv_profile_nama);
        TxEmail = (TextView) findViewById(R.id.tv_profile_email);
        TxProdi = (TextView) findViewById(R.id.tv_profile_prodi);
        TxClass = (TextView) findViewById(R.id.tv_profile_tampilclass);

        BtnLogout = (Button) findViewById(R.id.btLogout);

        TxNoInduk.setText( String.valueOf((dbHelper.getAllData().get(0)).get("no_induk")));
        TxNama.setText( String.valueOf((dbHelper.getAllData().get(0)).get("nama")));
        TxEmail.setText( String.valueOf((dbHelper.getAllData().get(0)).get("email")));
        TxProdi.setText( String.valueOf((dbHelper.getAllData().get(0)).get("prodi")));
        TxClass.setText( String.valueOf((dbHelper.getAllData().get(0)).get("class")));

        //k = String.valueOf(dbHelper.getAllData().get(0));

        BtnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent( ProfileActivity.this, LoginActivity.class));
            }
        });



    }
}
