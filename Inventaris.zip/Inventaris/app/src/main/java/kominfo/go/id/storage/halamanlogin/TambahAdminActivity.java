package kominfo.go.id.storage.halamanlogin;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TambahAdminActivity extends AppCompatActivity {    //private DatabaseHelperUser dbHelper;
    private EditText TxNoInduk;
    private EditText TxNama;
    private Spinner TxProdi,TxClass;
    private EditText TxEmail;
    private EditText TxPassword;
    Button BtnTambah;
    DatabaseHelperUser dbHelper;




    public static final String FILENAME = "tambahadmin";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tambah_admin);

        dbHelper = new DatabaseHelperUser(this);


        TxClass = (Spinner) findViewById(R.id.spinner_tambah_class);
        TxNoInduk = (EditText) findViewById(R.id.et_tambah_nip);
        TxNama = (EditText) findViewById(R.id.et_tambah_nama);
        TxPassword = (EditText) findViewById(R.id.et_tambah_password);
        TxProdi = (Spinner) findViewById(R.id.spinner_tambah_programstudi);
        TxEmail = (EditText) findViewById(R.id.et_tambah_email);
        BtnTambah = (Button) findViewById(R.id.btTambah);

        BtnTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String no_induk = TxNoInduk.getText().toString().trim();
                String nama = TxNama.getText().toString().trim();
                String email = TxEmail.getText().toString().trim();
                String prodi = TxProdi.getSelectedItem().toString().trim();
                String password = TxPassword.getText().toString().trim();
                String Class = TxClass.getSelectedItem().toString().trim();


                ContentValues values = new ContentValues();

                values.put(DatabaseHelperUser.COL_1, no_induk);
                values.put(DatabaseHelperUser.COL_2, nama);
                values.put(DatabaseHelperUser.COL_3, email);
                values.put(DatabaseHelperUser.COL_4, prodi);
                values.put(DatabaseHelperUser.COL_5, password);
                values.put(DatabaseHelperUser.COL_6, Class);
                dbHelper.addUser(values);
                Toast.makeText(TambahAdminActivity.this, "Tambah Sukses", Toast.LENGTH_SHORT).show();
                finish();
            }
        });






    }


}
